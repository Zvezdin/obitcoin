export const environment = {
  production: true,
  googleApi: 'AIzaSyBDlfj5NTyzDwY_w1JjtB21wIwvKqumMi0'
};
