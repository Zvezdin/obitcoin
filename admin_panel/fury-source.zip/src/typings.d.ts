declare module 'screenfull';
